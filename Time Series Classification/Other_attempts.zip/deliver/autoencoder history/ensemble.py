import os
import random
import numpy as np
import tensorflow as tf
import joblib
from sklearn.model_selection import train_test_split
import copy

# test of the ensemble model on the validation set

np.set_printoptions(formatter={'float': lambda x: "{0:0.2f}".format(x)})

path = os.path.join(os.path.dirname(__file__), 'autoencoder_test-16-12')

classe = [i for i in range(12)]
list_no = []
classes = [i for i in classe if i not in list_no]

# define the class
class model:
    def __init__(self, path):
        # array of autoencoders
        self.autoencoders = []
        # array of scalers
        self.scalers = []
        # load the pre-trained autoencoders and the scalers
        for i in classes:
            self.autoencoders.append(tf.keras.models.load_model(os.path.join(path, 'autoencoder_' + str(i) + '_17-12', f'autoencoder_{i}')))
            self.scalers.append(joblib.load(os.path.join(path, 'autoencoder_' + str(i) + '_17-12', 'scaler.gz')))

    def predict(self, X, true_labels):
        # Insert your preprocessing here
        # X = X.numpy()
        inputs = []
        print(X.shape)

        original_input = copy.deepcopy(X)

        # populate the array of inputs with the saler of each autoencoder
        for i in range(len(self.autoencoders)):
            X = original_input
            X = self.scalers[i].transform(X.reshape(-1, X.shape[-1])).reshape(X.shape)
            X = X.reshape((X.shape[0], -1, 1))
            X = X.squeeze(axis=2)
            inputs.append(X)

        # define the array of predictions
        predictions = []
        for i in range(len(self.autoencoders)):
            predictions.append(self.autoencoders[i].predict(inputs[i]))

        predictions = np.array(predictions)
        inputs = np.array(inputs)
        print(inputs.shape)

        ensemble_prediction = []
        print('number of predictions', predictions.shape[0])

        # iteate over the predictions of each autoencoder, for each sample
        for i, sample in enumerate(inputs[0]):
            # print(sample.shape)
            losses = []
            for j in range(predictions.shape[0]):
                # print(predictions[j][i].shape)
                mse = tf.keras.losses.MeanAbsoluteError()
                loss = mse(sample, predictions[j][i])
                losses.append(loss.numpy())
            print(losses, true_labels[i], classes[tf.argmin(losses).numpy()])
            ensemble_prediction.append(classes[tf.argmin(losses).numpy()])

        ensemble_prediction = np.array(ensemble_prediction)
        return ensemble_prediction

model = model(path)

seed = 42

random.seed(seed)
os.environ['PYTHONHASHSEED'] = str(seed)
np.random.seed(seed)
tf.random.set_seed(seed)
tf.compat.v1.set_random_seed(seed)

val_ds = []
true_labels = []

ds_dir = 'dataset_per_class'

for i in classes:
    x = np.load(os.path.join(ds_dir, str(i) + '.npy'))
    np.random.shuffle(x)
    x_train, x_val = train_test_split(x, train_size=0.75, random_state=seed)
    for j, sample in enumerate(x_val):
        val_ds.append(sample)
        true_labels.append(i)

val_ds = np.array(val_ds)
true_labels = np.array(true_labels)

print(true_labels)

print(val_ds.shape)
print(true_labels.shape)

print(classes)

preds = model.predict(val_ds, true_labels)

preds = list(preds)

print(classes)
print(preds)
print(list(true_labels))

# Count the number of correct predictions per class
correct = [0 for i in range(len(classes))]
for pred, sample in zip(preds, true_labels):
    if pred == sample:
        correct[classes.index(pred)] += 1

# Count the number of samples per class
samples = [0 for i in range(len(classes))]
for i in true_labels:
    samples[classes.index(i)] += 1

# Print the accuracy per class
for i in range(len(classes)):
    print(f'Class {classes[i]} accuracy: {correct[i] / samples[i]}')


# Count the number of correct predictions
correct = 0
for i in range(len(true_labels)):
    if preds[i] == true_labels[i]:
        correct += 1

print('number of correct predictions', correct)
acc = correct / len(true_labels)
print('Accuracy: ', acc)

